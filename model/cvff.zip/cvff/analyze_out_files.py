import os
import numpy as np
import matplotlib.pyplot as plt
import matplotlib.ticker as mticker  # 添加导入ticker模块用于整数坐标

def read_out_file(file_path):
    """Read LAMMPS output file and extract step, temperature, and density."""
    data = {'step': [], 'temp': [], 'density': []}
    
    with open(file_path, 'r') as f:
        # Skip header line
        next(f)
        for line in f:
            # Split line into columns
            columns = line.strip().split()
            if len(columns) >= 3:
                try:
                    step = int(columns[0])
                    temp = float(columns[1])
                    density = float(columns[2])
                    
                    data['step'].append(step)
                    data['temp'].append(temp)
                    data['density'].append(density)
                except (ValueError, IndexError):
                    continue
    
    return data

def ensure_output_dir(output_dir):
    """Create output directory if it doesn't exist."""
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    return output_dir

def combine_continuous_data(files_data):
    """Combine data from multiple files as continuous simulation."""
    combined_data = {'step': [], 'temp': [], 'density': []}
    last_step = 0
    
    # Sort files by iteration number
    sorted_files = sorted(files_data.items(), key=lambda x: int(x[0].split('_')[-1]))
    
    for label, data in sorted_files:
        iter_num = int(label.split('_')[-1])
        
        # Adjust steps to make them continuous
        adjusted_steps = [step + last_step for step in data['step']]
        
        # Combine data
        combined_data['step'].extend(adjusted_steps)
        combined_data['temp'].extend(data['temp'])
        combined_data['density'].extend(data['density'])
        
        # Update last step for next iteration
        if adjusted_steps:
            last_step = adjusted_steps[-1]
    
    return combined_data

def plot_temperature(files_data, output_dir='plots'):
    """Plot temperature vs step for all files."""
    output_path = os.path.join(output_dir, 'temperature_plot.png')
    plt.figure(figsize=(12, 8))
    
    # Get combined data for continuous simulation
    combined_data = combine_continuous_data(files_data)
    
    # Plot combined temperature data
    plt.plot(combined_data['step'], combined_data['temp'], label='Continuous Simulation', color='blue')
    
    # Add vertical lines to separate iterations
    last_step = 0
    sorted_files = sorted(files_data.items(), key=lambda x: int(x[0].split('_')[-1]))
    for label, data in sorted_files:
        if last_step > 0:
            plt.axvline(x=last_step, linestyle='--', color='gray', alpha=0.7)
            plt.text(last_step, plt.ylim()[1]*0.95, f"Iter {int(label.split('_')[-1])}", 
                    horizontalalignment='right', verticalalignment='top',
                    bbox=dict(boxstyle='round,pad=0.3', alpha=0.2))
        last_step += data['step'][-1]
    
    plt.xlabel('Simulation Step', fontsize=14)
    plt.ylabel('Temperature (K)', fontsize=14)
    plt.title('Temperature Evolution - Continuous Simulation', fontsize=16)
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_path, dpi=300)
    plt.close()
    
    return output_path

def plot_density(files_data, output_dir='plots'):
    """Plot density vs step for all files."""
    output_path = os.path.join(output_dir, 'density_plot.png')
    plt.figure(figsize=(12, 8))
    
    # Get combined data for continuous simulation
    combined_data = combine_continuous_data(files_data)
    
    # Plot combined density data
    plt.plot(combined_data['step'], combined_data['density'], label='Continuous Simulation', color='green')
    
    # Add vertical lines to separate iterations
    last_step = 0
    sorted_files = sorted(files_data.items(), key=lambda x: int(x[0].split('_')[-1]))
    for label, data in sorted_files:
        if last_step > 0:
            plt.axvline(x=last_step, linestyle='--', color='gray', alpha=0.7)
            plt.text(last_step, plt.ylim()[1]*0.95, f"Iter {int(label.split('_')[-1])}", 
                    horizontalalignment='right', verticalalignment='top',
                    bbox=dict(boxstyle='round,pad=0.3', alpha=0.2))
        last_step += data['step'][-1]
    
    plt.xlabel('Simulation Step', fontsize=14)
    plt.ylabel('Density (g/cm³)', fontsize=14)
    plt.title('Density Evolution - Continuous Simulation', fontsize=16)
    plt.grid(True, alpha=0.3)
    plt.legend()
    plt.tight_layout()
    plt.savefig(output_path, dpi=300)
    plt.close()
    
    return output_path

def plot_phase_diagram(files_data, output_dir='plots'):
    """Plot phase diagram (temperature vs density)."""
    output_path = os.path.join(output_dir, 'phase_diagram.png')
    plt.figure(figsize=(12, 8))
    
    # Get combined data for continuous simulation
    combined_data = combine_continuous_data(files_data)
    
    # Plot temperature vs density
    plt.scatter(combined_data['density'], combined_data['temp'], 
               c=np.arange(len(combined_data['step'])), cmap='viridis', 
               alpha=0.7, s=5)
    
    # Add colorbar to show time progression
    cbar = plt.colorbar()
    cbar.set_label('Simulation Progress', fontsize=12)
    
    plt.xlabel('Density (g/cm³)', fontsize=14)
    plt.ylabel('Temperature (K)', fontsize=14)
    plt.title('Phase Diagram - Temperature vs Density', fontsize=16)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(output_path, dpi=300)
    plt.close()
    
    return output_path

def plot_temperature_heatmap(files_data, output_dir='plots'):
    """Create a heatmap of temperature evolution over time."""
    output_path = os.path.join(output_dir, 'temperature_heatmap.png')
    
    # Get combined data
    combined_data = combine_continuous_data(files_data)
    
    # Create a 2D array representing temperature over time
    # First bin the data to create a more manageable array
    num_bins = 100  # Number of time bins
    max_temp = max(combined_data['temp'])
    min_temp = min(combined_data['temp'])
    temp_bins = 50  # Number of temperature bins
    
    # Create histogram2d
    h, xedges, yedges = np.histogram2d(
        combined_data['step'], 
        combined_data['temp'],
        bins=[num_bins, temp_bins],
        range=[[min(combined_data['step']), max(combined_data['step'])], 
               [min_temp, max_temp]]
    )
    
    # Plot heatmap
    plt.figure(figsize=(14, 8))
    plt.imshow(h.T, aspect='auto', origin='lower', 
              extent=[min(combined_data['step']), max(combined_data['step']), min_temp, max_temp],
              cmap='plasma', interpolation='bilinear')
    
    plt.colorbar(label='Frequency')
    
    # Add vertical lines to separate iterations
    last_step = 0
    sorted_files = sorted(files_data.items(), key=lambda x: int(x[0].split('_')[-1]))
    for label, data in sorted_files:
        if last_step > 0:
            plt.axvline(x=last_step, linestyle='--', color='white', alpha=0.5)
            plt.text(last_step, max_temp*0.95, f"Iter {int(label.split('_')[-1])}", 
                    color='white', horizontalalignment='right', verticalalignment='top')
        last_step += data['step'][-1]
    
    plt.ylabel('Temperature (K)', fontsize=14)
    plt.xlabel('Simulation Step', fontsize=14)
    plt.title('Temperature Distribution over Time', fontsize=16)
    plt.tight_layout()
    plt.savefig(output_path, dpi=300)
    plt.close()
    
    return output_path

def plot_combined_stats(files_data, output_dir='plots'):
    """Create a combined plot showing temperature and density statistics."""
    output_path = os.path.join(output_dir, 'combined_stats.png')
    
    # Create figure with two subplots
    fig, (ax1, ax2) = plt.subplots(2, 1, figsize=(12, 12), sharex=True)
    
    # Get combined data for continuous simulation
    combined_data = combine_continuous_data(files_data)
    
    # Plot temperature data on top subplot
    ax1.plot(combined_data['step'], combined_data['temp'], label='Temperature', color='red')
    ax1.set_ylabel('Temperature (K)', fontsize=14)
    ax1.set_title('Temperature Evolution - Continuous Simulation', fontsize=16)
    ax1.grid(True, alpha=0.3)
    
    # Add vertical lines to separate iterations
    last_step = 0
    sorted_files = sorted(files_data.items(), key=lambda x: int(x[0].split('_')[-1]))
    for label, data in sorted_files:
        if last_step > 0:
            ax1.axvline(x=last_step, linestyle='--', color='gray', alpha=0.7)
            ax1.text(last_step, ax1.get_ylim()[1]*0.95, f"Iter {int(label.split('_')[-1])}", 
                    horizontalalignment='right', verticalalignment='top',
                    bbox=dict(boxstyle='round,pad=0.3', alpha=0.2))
        last_step += data['step'][-1]
    
    # Plot density data on bottom subplot
    ax2.plot(combined_data['step'], combined_data['density'], label='Density', color='green')
    
    # Add vertical lines again for the density plot
    last_step = 0
    for label, data in sorted_files:
        if last_step > 0:
            ax2.axvline(x=last_step, linestyle='--', color='gray', alpha=0.7)
            ax2.text(last_step, ax2.get_ylim()[1]*0.95, f"Iter {int(label.split('_')[-1])}", 
                    horizontalalignment='right', verticalalignment='top',
                    bbox=dict(boxstyle='round,pad=0.3', alpha=0.2))
        last_step += data['step'][-1]
    
    ax2.set_xlabel('Simulation Step', fontsize=14)
    ax2.set_ylabel('Density (g/cm³)', fontsize=14)
    ax2.set_title('Density Evolution - Continuous Simulation', fontsize=16)
    ax2.grid(True, alpha=0.3)
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=300)
    plt.close()
    
    return output_path

def plot_convergence(files_data, output_dir='plots'):
    """Plot convergence of temperature and density over iterations."""
    output_path = os.path.join(output_dir, 'convergence_plot.png')
    
    # Create figure with two subplots
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 8))
    
    # Calculate statistics for each iteration
    iterations = []
    avg_temps = []
    final_temps = []
    avg_densities = []
    final_densities = []
    
    sorted_files = sorted(files_data.items(), key=lambda x: int(x[0].split('_')[-1]))
    for label, data in sorted_files:
        iter_num = int(label.split('_')[-1])
        iterations.append(iter_num)
        
        # Calculate average and final values
        avg_temps.append(np.mean(data['temp']))
        final_temps.append(data['temp'][-1])
        avg_densities.append(np.mean(data['density']))
        final_densities.append(data['density'][-1])
    
    # Plot temperature convergence
    ax1.plot(iterations, avg_temps, 'o-', label='Average Temperature', color='red')
    ax1.plot(iterations, final_temps, 's-', label='Final Temperature', color='darkred')
    ax1.set_xlabel('Iteration', fontsize=14)
    ax1.set_ylabel('Temperature (K)', fontsize=14)
    ax1.set_title('Temperature Convergence', fontsize=16)
    ax1.grid(True, alpha=0.3)
    ax1.legend()
    
    # 确保迭代横坐标为整数
    ax1.xaxis.set_major_locator(mticker.MaxNLocator(integer=True))
    
    # Plot density convergence
    ax2.plot(iterations, avg_densities, 'o-', label='Average Density', color='green')
    ax2.plot(iterations, final_densities, 's-', label='Final Density', color='darkgreen')
    ax2.set_xlabel('Iteration', fontsize=14)
    ax2.set_ylabel('Density (g/cm³)', fontsize=14)
    ax2.set_title('Density Convergence', fontsize=16)
    ax2.grid(True, alpha=0.3)
    ax2.legend()
    
    # 确保迭代横坐标为整数
    ax2.xaxis.set_major_locator(mticker.MaxNLocator(integer=True))
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=300)
    plt.close()
    
    return output_path

def plot_iteration_comparison(files_data, output_dir='plots'):
    """比较不同迭代中的温度和密度分布"""
    output_path = os.path.join(output_dir, 'iteration_comparison.png')
    
    # 创建图表
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(16, 8))
    
    # 整理每次迭代的数据
    sorted_files = sorted(files_data.items(), key=lambda x: int(x[0].split('_')[-1]))
    
    # 为每次迭代绘制箱线图数据
    temp_data = []
    density_data = []
    iter_labels = []
    
    for label, data in sorted_files:
        iter_num = int(label.split('_')[-1])
        iter_labels.append(str(iter_num))
        temp_data.append(data['temp'])
        density_data.append(data['density'])
    
    # 绘制温度箱线图
    ax1.boxplot(temp_data, labels=iter_labels, patch_artist=True,
               boxprops=dict(facecolor='lightblue', color='blue'),
               whiskerprops=dict(color='blue'),
               capprops=dict(color='blue'),
               medianprops=dict(color='darkblue'))
    
    ax1.set_xlabel('Iteration', fontsize=14)
    ax1.set_ylabel('Temperature (K)', fontsize=14)
    ax1.set_title('Temperature Distribution by Iteration', fontsize=16)
    ax1.grid(True, alpha=0.3, axis='y')
    
    # 确保迭代横坐标为整数
    ax1.xaxis.set_major_locator(mticker.MaxNLocator(integer=True))
    
    # 绘制密度箱线图
    ax2.boxplot(density_data, labels=iter_labels, patch_artist=True,
               boxprops=dict(facecolor='lightgreen', color='green'),
               whiskerprops=dict(color='green'),
               capprops=dict(color='green'),
               medianprops=dict(color='darkgreen'))
    
    ax2.set_xlabel('Iteration', fontsize=14)
    ax2.set_ylabel('Density (g/cm³)', fontsize=14)
    ax2.set_title('Density Distribution by Iteration', fontsize=16)
    ax2.grid(True, alpha=0.3, axis='y')
    
    # 确保迭代横坐标为整数
    ax2.xaxis.set_major_locator(mticker.MaxNLocator(integer=True))
    
    plt.tight_layout()
    plt.savefig(output_path, dpi=300)
    plt.close()
    
    return output_path

def main():
    # Get script directory
    script_dir = os.path.dirname(os.path.abspath(__file__))
    
    # Create output directory as a subfolder of the script directory
    output_dir = os.path.join(script_dir, 'plots')
    ensure_output_dir(output_dir)
    
    # Define the output files to analyze
    out_files = [
        os.path.join(script_dir, 'PBI_5_75_cvff_0.out'),
        os.path.join(script_dir, 'PBI_5_75_cvff_1.out'),
        os.path.join(script_dir, 'PBI_5_75_cvff_2.out')
    ]
    
    # Read data from all files
    files_data = {}
    for file_path in out_files:
        label = os.path.basename(file_path).replace('.out', '')
        files_data[label] = read_out_file(file_path)
    
    # Generate plots
    plot_paths = []
    
    # Standard plots
    plot_paths.append(plot_temperature(files_data, output_dir))
    plot_paths.append(plot_density(files_data, output_dir))
    plot_paths.append(plot_combined_stats(files_data, output_dir))
    
    # Additional plots for continuous simulation analysis
    plot_paths.append(plot_phase_diagram(files_data, output_dir))
    plot_paths.append(plot_convergence(files_data, output_dir))
    plot_paths.append(plot_iteration_comparison(files_data, output_dir))
    
    try:
        plot_paths.append(plot_temperature_heatmap(files_data, output_dir))
    except Exception as e:
        print(f"Failed to create temperature heatmap: {e}")
        print("Continuing with other plots.")
    
    print(f"Analysis complete. Generated plots in: {output_dir}")
    for path in plot_paths:
        print(f"- {os.path.basename(path)}")

if __name__ == "__main__":
    main() 